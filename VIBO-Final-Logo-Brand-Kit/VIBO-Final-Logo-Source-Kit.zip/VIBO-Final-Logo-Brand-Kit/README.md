# VIBO Final Logo Brand Kit

This package contains the user-approved VIBO logo direction: a blue-violet concentric ring with a solid center dot and the VIBO wordmark.

## Contents
- `vector/`: color, black, and white logo versions in vertical and horizontal lockups (`.svg`, `.eps`, `.ai`).
- `bitmap/`: transparent PNGs with 300 dpi metadata, for all six lockups.
- `preview/`: JPG previews on a white background.
- `documentation/VIBO-Logo-Usage-Guide.pdf`: logo colors, recommended Pantone references, usage rules, size, clear space, and font note.
- `documentation/VIBO-Copyright-Assignment-Draft.pdf`: fill-in rights assignment document for the rights holder and recipient to review and sign.

## Technical notes
- SVGs are the editable masters and contain named groups for the symbol and wordmark. EPS files retain vector paths and gradient shading.
- `.ai` files are PDF-compatible Illustrator handoff documents, editable as vector artwork in Adobe Illustrator. The SVG files are the source masters with named groups; after opening an AI handoff, users can place groups into separate Illustrator layers if needed.
- The wordmark is converted to vector outlines. No third-party font file is bundled or required.
- Pantone values are close coated-stock references only; gradients cannot be represented by one spot color. Confirm against a physical Pantone guide and print profile.
- Copyright assignment is a draft and is not effective until completed and signed by the actual rights holder and recipient. The package does not claim that a transfer has already occurred.

## Quality check
The vertical color SVG was rasterized at 8000 px wide (10× the 800 px SVG artboard). Edges remained clean. Transparent PNGs carry 300 dpi metadata.
