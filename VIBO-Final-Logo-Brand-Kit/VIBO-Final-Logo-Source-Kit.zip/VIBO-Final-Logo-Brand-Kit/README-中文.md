# VIBO 定稿 Logo 交付包

本包按已确认的定稿方向制作：蓝紫渐变同心圆环、实心中心圆点及 VIBO 字标。

## 文件内容
- `vector/`：彩色、纯黑、纯白版本；横版、竖版；SVG、EPS、AI。
- `bitmap/`：透明底 PNG，含 300 dpi 元数据，共六版。
- `preview/`：白底 JPG 预览图。
- `documentation/VIBO-Logo-Usage-Guide.pdf`：色值、Pantone 近似参考、字体说明、最小尺寸、安全留白与使用规范。
- `documentation/VIBO-Copyright-Assignment-Draft.pdf`：待权利人和受让方填写、审阅并签署的版权转让证明草案。

## 技术说明
- SVG 是可编辑矢量主稿，图形标志和字标分别分组命名；EPS 保留矢量路径及渐变。
- `.ai` 为 PDF 兼容的 Illustrator 矢量交接文件，可在 Adobe Illustrator 中编辑。SVG 主稿保留命名分组；如需 AI 内分层，可在 Illustrator 打开后将分组放入单独图层。
- VIBO 字标已转为矢量轮廓，不依赖或附带第三方字体文件。
- Pantone 仅为铜版纸近似专色参考；渐变不能用一个专色准确表达，请以实体 Pantone 色卡及印刷色彩配置文件核对。
- 版权文件是待签署草案。实际权利人及受让方完成填写和签署前，不代表版权已经转让。

## 清晰度自检
竖版彩色 SVG 已按 8000 px 宽度（相对 800 px 画板放大 10 倍）渲染检查，边缘保持清晰；透明 PNG 含 300 dpi 元数据。
